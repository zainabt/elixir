module Main where

main :: IO ()
main = Polarity.main
